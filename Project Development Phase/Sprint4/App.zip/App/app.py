from flask import Flask, redirect, render_template, request, url_for,session
import ibm_db
import re
app=Flask(_name_)
app.secret_key = 'a'
conn=ibm_db.connect("DATABASE=bludb;HOSTNAME=3883e7e4-18f5-4afe-be8c-fa31c41761d2.bs2io90l08kqb1od8lcg.databases.appdomain.cloud;PORT=31498;SECURITY=SSL;SSLServerCertificate=DigiCertGlobalRootCA.crt; UID=kkt67169;PWD=dYoul9V9NLi5dzBo;",'','')

@app.route('/signin',methods=['GET','POST'])
def signin():
    global userid
    msg="  "
       
    
    if request.method == 'POST' :
        Email = request.form['Email']
        Pass_word = request.form['Pass_word']
        sql = "SELECT * FROM users WHERE Email =? AND Pass_word=?"
        stmt = ibm_db.prepare(conn, sql)
        ibm_db.bind_param(stmt,1,Email)
        ibm_db.bind_param(stmt,2,Pass_word)
        ibm_db.execute(stmt)
        account = ibm_db.fetch_assoc(stmt)
        print (account)
        if account:
            session['loggedin'] = True
            session['id'] = account['Email']
            userid=  account['Email']
            session['Email'] = account['Email']
            msg = 'Logged in successfully !'
            return render_template('welcome.html', msg = msg)
        else:
            msg = 'Incorrect email / password !'
    return render_template('index.html', msg = msg)


@app.route('/', methods =['GET', 'POST'])
def register():
    msg =" "
    if request.method == 'POST' :
        username = request.form['username']
        roll_no = request.form['roll_no']
        email = request.form['email']
        passwd = request.form['passwd']
        sql = "SELECT * FROM USER WHERE username =?"
        stmt = ibm_db.prepare(conn, sql)
        ibm_db.bind_param(stmt,1,username)
        ibm_db.execute(stmt)
        account = ibm_db.fetch_assoc(stmt)
        print(account)
        if account:
            msg = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address !'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'name must contain only characters and numbers !'
        else:
            insert_sql = "INSERT INTO  USER VALUES (?, ?, ?, ?)"
            prep_stmt = ibm_db.prepare(conn, insert_sql)
            ibm_db.bind_param(prep_stmt, 1, roll_no)
            ibm_db.bind_param(prep_stmt, 2, username)
            
            ibm_db.bind_param(prep_stmt, 3, email)
            ibm_db.bind_param(prep_stmt, 4, passwd)
            ibm_db.execute(prep_stmt)
            msg = 'You have successfully registered !'
            return render_template('login.html',msg=msg)
    elif request.method == 'POST':
        msg = 'Please fill out the form !'
    return render_template('register.html', msg = msg)

    
if _name_ == '_main_':
   app.run()


